Files in this folder can be used to compile auxiliary program that can
be used for running command prompt commands skipping standard "cmd /c" way. 
They are licensed under the terms of the GNU Lesser General Public License.
